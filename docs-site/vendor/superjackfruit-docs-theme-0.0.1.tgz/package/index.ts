// @superjackfruit/docs-theme: the suite's docs design as one Starlight plugin. A site's whole
// design config is
//
//   starlight({ title, plugins: [sjlDocs({ product: 'superdispatch' })], sidebar })
//
// and the plugin brings the rest: vibekit's colours for the product, the shared fonts (self-hosted),
// the site title, the street as the suite map, the status badges, Copy Markdown, the footers, the
// 404, llms.txt, the edit link and last-updated dates, and a check that the sidebar uses the
// suite's five groups. Components for pages (BentoHome, CaptainJack, FlowSteps, the callouts) are
// imported from '@superjackfruit/docs-theme/components/<Name>.astro'.
//
// TypeScript on purpose, like starlight-llms-txt: Node will not run TypeScript from node_modules,
// so Astro loads a config that imports this file through Vite, which compiles it.
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import starlightLlmsTxt from 'starlight-llms-txt';
import { PRODUCT_ACCENTS } from '@superjackfruit/vibekit/appearance';
import { ORDER, PRODUCTS, type Slug } from '@superjackfruit/frontdoor/data';
import type { StarlightPlugin } from '@astrojs/starlight/types';
import { sidebarWarnings } from './src/sidebar.mjs';
import { statusOf, themeCss } from './src/tokens.mjs';

const require = createRequire(import.meta.url);
const C = (name: string) => `@superjackfruit/docs-theme/components/${name}.astro`;

/** The theme's CSS for one product: vibekit's tokens for it, light and dark. */
export function productCss(product: string): string {
  const accent = (PRODUCT_ACCENTS as Record<string, string>)[product];
  if (!accent) throw new Error(`docs-theme: vibekit names no accent for "${product}"`);
  const read = (spec: string) => readFileSync(require.resolve(spec), 'utf8');
  return themeCss(read('@superjackfruit/vibekit/accents.css'), read('@superjackfruit/vibekit/tokens.css'), accent);
}

export interface SjlDocsOptions {
  /** The product's slug, as in frontdoor's product list ('superdispatch'). */
  product: Slug;
  /** The site's status word, beside its title: "wet paint", "half-lit", "lights on" or "lit & steady". */
  status?: string;
  /** The docs site's folder in the repo, for the edit link (default 'docs-site/'). */
  docsDir?: string;
  /** Options for starlight-llms-txt (on by default), or false to leave it off. */
  llms?: false | { description?: string; details?: string; optionalLinks?: { label: string; url: string; description?: string }[] };
}

export default function sjlDocs(options: SjlDocsOptions): StarlightPlugin {
  const { product, docsDir = 'docs-site/' } = options ?? ({} as SjlDocsOptions);
  const me = (PRODUCTS as Record<string, (typeof PRODUCTS)[Slug]>)[product];
  if (!me) throw new Error(`docs-theme: unknown product "${product}"; one of ${ORDER.join(', ')}`);
  const status = options.status === undefined ? undefined : statusOf(options.status);
  if (options.status !== undefined && !status) throw new Error(`docs-theme: status "${options.status}" is not one of wet paint, half-lit, lights on, lit & steady`);
  const llms = options.llms === false ? null : starlightLlmsTxt({
    projectName: me.name,
    description: options.llms?.description ?? `${me.name}: ${me.line}`,
    ...(options.llms?.details ? { details: options.llms.details } : {}),
    optionalLinks: options.llms?.optionalLinks ?? [
      { label: me.name, url: me.url, description: 'The product site.' },
      ...(me.repo ? [{ label: 'Source', url: me.repo, description: `The ${me.name} repository.` }] : []),
    ],
  });

  return {
    name: '@superjackfruit/docs-theme',
    hooks: {
      async 'config:setup'(ctx) {
        const { config, updateConfig, addIntegration, logger } = ctx;
        for (const w of sidebarWarnings(config.sidebar)) logger.warn(w);

        const theme = { product, name: me.name, landing: me.url, status: status ?? null };
        updateConfig({
          components: {
            SiteTitle: C('SiteTitle'),
            Header: C('Header'),
            PageTitle: C('PageTitle'),
            Footer: C('Footer'),
            ...config.components,
          },
          customCss: ['@superjackfruit/docs-theme/styles/fonts.css', '@superjackfruit/docs-theme/styles/theme.css', ...(config.customCss ?? [])],
          head: [
            { tag: 'style', attrs: { 'data-sjl-docs': product }, content: productCss(product) },
            ...(config.head ?? []),
          ],
          editLink: config.editLink?.baseUrl ? config.editLink : me.repo ? { baseUrl: `${me.repo}/edit/main/${docsDir}` } : config.editLink,
          lastUpdated: config.lastUpdated ?? true,
          disable404Route: true,
        });

        addIntegration({
          name: '@superjackfruit/docs-theme/routes',
          hooks: {
            'astro:config:setup'({ injectRoute, updateConfig: updateAstro }) {
              injectRoute({ pattern: '404', entrypoint: '@superjackfruit/docs-theme/pages/404.astro', prerender: true });
              // The theme's settings, for its components (virtual module: no file in the site).
              updateAstro({ vite: { plugins: [virtualTheme(theme)] } });
            },
          },
        });

        if (llms) {
          const hooks = llms.hooks as Record<string, ((c: typeof ctx) => unknown) | undefined>;
          const setup = hooks['config:setup'] ?? hooks.setup;
          await setup?.(ctx);
        }
      },
    },
  };
}

function virtualTheme(theme: object) {
  const id = 'virtual:sjl-docs/theme';
  return {
    name: 'sjl-docs-theme',
    resolveId: (x: string) => (x === id ? `\0${id}` : undefined),
    load: (x: string) => (x === `\0${id}` ? `export default ${JSON.stringify(theme)};` : undefined),
  };
}

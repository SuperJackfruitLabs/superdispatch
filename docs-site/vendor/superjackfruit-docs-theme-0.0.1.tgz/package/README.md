# @superjackfruit/docs-theme

The suite's docs design, as one Starlight plugin. A product's docs site sets its title, its sidebar and this:

```js
// astro.config.mjs
import starlight from '@astrojs/starlight';
import sjlDocs from '@superjackfruit/docs-theme';

starlight({
  title: 'SuperDispatch',
  plugins: [sjlDocs({ product: 'superdispatch', status: 'wet paint' })],
  sidebar: [/* Start, Use it, Build on it, Run it, Reference */],
});
```

```ts
// src/content.config.ts: Starlight's schema plus `status:`
import { defineCollection } from 'astro:content';
import { docsLoader } from '@astrojs/starlight/loaders';
import { sjlDocsSchema } from '@superjackfruit/docs-theme/schema';

export const collections = { docs: defineCollection({ loader: docsLoader(), schema: sjlDocsSchema() }) };
```

## What the plugin brings

- **Colours from vibekit.** It reads the product's accent from vibekit's `PRODUCT_ACCENTS` and its Daylight values from `accents.css`, for light and dark. Every site shares one neutral grey scale, so the products differ only in their accent. No product colour is typed in this package.
- **Faces, self-hosted.** Bricolage Grotesque for display, IBM Plex Sans for body text and IBM Plex Mono for code. The font files are bundled into the site, so no page fetches a font from Google.
- **The header.** The site title shows the product's mark and name, plus the site's status when the `status` option is set. Above it, the street is the suite map: one house per product, leading to that product's docs. On a phone the street folds into a product switcher. The header also links to the product's landing page.
- **Page titles.** Each page gets a status badge from its frontmatter `status:` and a Copy Markdown button.
- **The foot of the page.** Starlight's own edit link, last-updated date and previous/next links come first, then frontdoor's suite footer.
- **A 404 with character**: "You've wandered off the street", with search, a link to the docs home and a link to the landing page.
- **Defaults**: `starlight-llms-txt` is on (`llms: false` turns it off), `editLink` points at the product's repo (`docsDir` sets the folder, `docs-site/` by default), and `lastUpdated: true`. A site's own settings win.
- **A sidebar check.** The build warns when the top-level groups are not Start / Use it / Build on it / Run it / Reference, in that order. A site may leave groups out.

## Status words

| Word | Means |
|---|---|
| lit & steady | In production, stable, relied on daily. |
| lights on | In production, still changing. |
| half-lit | Works, with known gaps the page names. |
| wet paint | New or experimental. |

Each badge is filled with vibekit's mood colours, never the accent.

## Components for pages

Import these in `.mdx` from `@superjackfruit/docs-theme/components/<Name>.astro`.

- `BentoHome`: the docs home, for `index.mdx` with `template: splash` and no `hero`. It takes `claim`, `sub`, `actions`, `quickstart` (`{ command, note? }`), `status`, `ask` (`{ examples }`, or `false`), `flowTitle` and `map`. Whatever you put inside it fills the "how it works" tile.
- `FlowSteps`: a process the reader steps through with a slider or Back and Next. It never plays by itself. Without JavaScript, or when the reader prefers reduced motion, it shows a still: every step written out, or the `still` image if you give one.
- `CaptainJack`: the Ask box. It sends the question to the suite worker at this site's own `/captain/`. Captain Jack answers only from the product's docs and the lab's checked claims, and links each docs passage he cites. When the docs don't cover a question, he says "I don't know".
- `Tip`, `HeadsUp`, `WetPaint`, `JackAside`: the callouts.
- `StatusBadge`: a status word as a pill.

## Peers

`astro` 7, `@astrojs/starlight` 0.42, `starlight-llms-txt` 0.12, `@superjackfruit/vibekit` 0.0.16 or later, and `@superjackfruit/frontdoor` 0.0.15 or later (product list, marks and suite footer). Both `@superjackfruit` packages are vendored as tarballs, the way the landing pages vendor them.

## Tests

`npm test` builds `fixture/`, a small Starlight site that wears the theme. It then checks that build, the plugin's config, the tokens against vibekit's own CSS, and contrast for every product in light and dark.

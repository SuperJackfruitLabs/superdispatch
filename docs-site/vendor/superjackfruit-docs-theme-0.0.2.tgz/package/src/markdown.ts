// A page as Markdown, the way its author wrote it: the title, then the body with MDX imports
// dropped. Copy Markdown copies this text, and every page serves it at its own `.md` address
// (src/pages/markdown.ts), so the button and the link always agree.

export function pageMarkdown(title: string, body?: string): string {
  const text = (body ?? '').replace(/^import\s.+?;?\s*$/gm, '').replace(/^\n+/, '');
  return `# ${title}\n\n${text}`.trimEnd() + '\n';
}

/** Where a page's Markdown is served: its id plus `.md` (`start/first-steps.md`, `index.md`). */
export function markdownHref(id: string, base = '/'): string {
  return `${base.endsWith('/') ? base : `${base}/`}${id || 'index'}.md`;
}

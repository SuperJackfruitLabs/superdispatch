// Ids for a step component's tabs and panels: unique on the page, so two FlowSteps (or a
// FlowSteps and a DecisionReplay) never point at each other's panels.
let seq = 0;
export function stepIds(prefix: string, n: number) {
  const base = `sjl-${prefix}-${(++seq).toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  if (n < 1) throw new Error('docs-theme: a step component needs at least one step');
  return { base, tab: (i: number) => `${base}-tab-${i}`, panel: (i: number) => `${base}-panel-${i}` };
}

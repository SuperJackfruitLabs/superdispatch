// The docs collection's frontmatter: Starlight's own, plus `status:`, which puts a status badge
// beside the page title. In a site's src/content.config.ts:
//
//   import { defineCollection } from 'astro:content';
//   import { docsLoader } from '@astrojs/starlight/loaders';
//   import { sjlDocsSchema } from '@superjackfruit/docs-theme/schema';
//   export const collections = { docs: defineCollection({ loader: docsLoader(), schema: sjlDocsSchema() }) };
import { docsSchema } from '@astrojs/starlight/schema';
import { z } from 'astro/zod';
import { STATUS_KEYS, STATUSES, statusOf } from './tokens.mjs';

/** "lit & steady", "lights on", "half-lit" or "wet paint" (or their keys); anything else fails the build. */
export const statusField = z
  .string()
  .refine((v) => statusOf(v) !== undefined, { message: `status must be one of: ${STATUS_KEYS.map((k) => STATUSES[k].label).join(', ')}` })
  .transform((v) => statusOf(v))
  .optional();

export const sjlDocsSchema = () => docsSchema({ extend: z.object({ status: statusField }) });

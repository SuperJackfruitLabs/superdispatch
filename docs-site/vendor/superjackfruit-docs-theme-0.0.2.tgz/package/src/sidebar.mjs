// Every suite docs site groups its pages the same way, so a reader who knows one knows them all:
// Start, Use it, Build on it, Run it, Reference, in that order. A site may leave a group out; any
// other top-level group, or the right groups out of order, is a warning at build time.

export const GROUPS = ['Start', 'Use it', 'Build on it', 'Run it', 'Reference'];

/** The warnings for a sidebar config; empty when it follows the suite's groups. */
export function sidebarWarnings(sidebar) {
  if (!Array.isArray(sidebar)) return [];
  const labels = sidebar.map((x) => (typeof x === 'object' && x && typeof x.label === 'string' ? x.label : null));
  const out = [];
  const odd = labels.filter((l) => l !== null && !GROUPS.includes(l));
  if (odd.length) out.push(`top-level sidebar groups ${odd.map((l) => `"${l}"`).join(', ')} are not one of ${GROUPS.join(' / ')}`);
  if (labels.some((l) => l === null)) out.push('a top-level sidebar entry is a page, not a group; put it under one of ' + GROUPS.join(' / '));
  const known = labels.filter((l) => l !== null && GROUPS.includes(l));
  const order = known.map((l) => GROUPS.indexOf(l));
  if (order.some((n, i) => i > 0 && n <= order[i - 1])) out.push(`sidebar groups should run ${GROUPS.join(', ')}; these run ${known.join(', ')}`);
  return out;
}

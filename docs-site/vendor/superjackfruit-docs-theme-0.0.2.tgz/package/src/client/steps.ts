// The step pattern FlowSteps and DecisionReplay share: a tablist of numbered steps, one panel per
// step, and Back and Next. It follows the tabs pattern in Vercel's UI SDK docs
// (ui-sdk.dev/docs/components/tabs, /docs/core/behaviors/focus):
//
// - one tab stop for the group (a roving tabindex: the selected step's tab is 0, the rest -1);
// - Left and Right move along the steps in the page's text direction, Home and End go to the
//   first and last step, and the arrows stop at either end unless the component asks to loop;
// - moving to a tab selects it (aria-selected) and shows its panel (aria-controls, role
//   tabpanel); the other panels are hidden;
// - Back and Next stay focusable at either end (aria-disabled, not disabled), so focus never
//   falls to the page when a button runs out of steps;
// - nothing moves by itself.
//
// The markup arrives server-rendered with every panel visible and the tablist and buttons hidden,
// so without JavaScript the reader gets every step written out. bindSteps turns it live.

export interface StepsOptions {
  /** Wrap from the last step to the first and back. Off by default. */
  loop?: boolean;
  /** Called after every change of step, with the new index. */
  onStep?: (index: number) => void;
}

export function bindSteps(root: HTMLElement, options: StepsOptions = {}): { select: (i: number, focus?: boolean) => void } | null {
  const list = root.querySelector<HTMLElement>('[role="tablist"]');
  if (!list) return null;
  const tabs = [...list.querySelectorAll<HTMLElement>('[role="tab"]')];
  const panels = tabs.map((t) => document.getElementById(t.getAttribute('aria-controls') ?? ''));
  if (!tabs.length || panels.some((p) => !p)) return null;
  const back = root.querySelector<HTMLButtonElement>('[data-step="back"]');
  const next = root.querySelector<HTMLButtonElement>('[data-step="next"]');
  const count = root.querySelector<HTMLElement>('[data-step="count"]');
  const controls = root.querySelector<HTMLElement>('[data-step="controls"]');
  const n = tabs.length;
  let current = Math.max(0, tabs.findIndex((t) => t.getAttribute('aria-selected') === 'true'));

  const select = (i: number, focus = false) => {
    current = Math.max(0, Math.min(n - 1, i));
    tabs.forEach((t, k) => {
      t.setAttribute('aria-selected', String(k === current));
      t.tabIndex = k === current ? 0 : -1;
    });
    panels.forEach((p, k) => { p!.hidden = k !== current; });
    back?.setAttribute('aria-disabled', String(current === 0));
    next?.setAttribute('aria-disabled', String(current === n - 1));
    if (count) count.textContent = `Step ${current + 1} of ${n}`;
    root.dataset.current = String(current);
    if (focus) tabs[current]!.focus();
    options.onStep?.(current);
  };

  list.addEventListener('keydown', (e) => {
    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    const from = tabs.indexOf(e.target as HTMLElement);
    if (from < 0) return;
    const rtl = getComputedStyle(list).direction === 'rtl';
    let to: number;
    switch (e.key) {
      case 'ArrowRight': to = from + (rtl ? -1 : 1); break;
      case 'ArrowLeft': to = from + (rtl ? 1 : -1); break;
      case 'Home': to = 0; break;
      case 'End': to = n - 1; break;
      default: return;
    }
    e.preventDefault();
    if (options.loop) to = (to + n) % n;
    if (to < 0 || to >= n || to === from) return;
    select(to, true);
  });
  tabs.forEach((t, k) => t.addEventListener('click', () => select(k)));
  // Focus stays on the button pressed: a step change never moves it.
  back?.addEventListener('click', () => { if (current > 0) select(current - 1); });
  next?.addEventListener('click', () => { if (current < n - 1) select(current + 1); });

  list.hidden = false;
  if (controls) controls.hidden = false;
  root.classList.add('live');
  select(current);
  return { select };
}

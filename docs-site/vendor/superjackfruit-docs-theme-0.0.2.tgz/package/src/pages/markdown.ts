// Every docs page as Markdown at its own address, `<page>.md`, for an agent or a reader who wants
// the source. The same text Copy Markdown copies (src/markdown.ts).
import type { APIRoute, GetStaticPaths } from 'astro';
import { getCollection } from 'astro:content';
import { pageMarkdown } from '../markdown.ts';

export const prerender = true;

export const getStaticPaths = (async () => {
  const docs = await getCollection('docs', (e) => !(e.data as { draft?: boolean }).draft);
  return docs.map((e) => ({ params: { slug: e.id || 'index' }, props: { title: e.data.title, body: e.body } }));
}) satisfies GetStaticPaths;

export const GET: APIRoute = ({ props }) =>
  new Response(pageMarkdown(props.title as string, props.body as string | undefined), {
    headers: { 'content-type': 'text/markdown; charset=utf-8' },
  });

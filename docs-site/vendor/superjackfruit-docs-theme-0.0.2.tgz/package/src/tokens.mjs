// The theme's colours. Every colour a product owns comes from vibekit: its accent (PRODUCT_ACCENTS
// names it, accents.css holds its Daylight values for light and dark) and the status colours (the
// mood fills of tokens.css). The one thing the theme owns is the neutral grey scale, the same on
// every docs site, so the products differ only by their accent. No product colour is typed here.
//
// Pure functions over the CSS text, so the tests can run them on vibekit's real files.

export const THEMES = ['light', 'dark'];
export const VIBE = 'daylight';

/** The custom properties of the first block whose selector list contains `selector`. */
export function block(css, selector) {
  const at = css.indexOf(selector);
  if (at < 0) throw new Error(`docs-theme: vibekit CSS has no ${selector}`);
  const body = css.slice(css.indexOf('{', at) + 1, css.indexOf('}', at));
  return Object.fromEntries([...body.matchAll(/(--[\w-]+)\s*:\s*([^;]+);/g)].map((m) => [m[1], m[2].trim().toLowerCase()]));
}

const need = (vars, name, where) => {
  const v = vars[name];
  if (!v || !/^#[0-9a-f]{6}$/.test(v)) throw new Error(`docs-theme: ${where} has no ${name} as #rrggbb`);
  return v;
};

/** One theme's product accent, as vibekit's Daylight look draws it. */

export function accentOf(accentsCss, accent, theme) {
  const sel = `[data-vibe="${VIBE}"][data-theme="${theme}"][data-accent="${accent}"]`;
  const v = block(accentsCss, sel);
  return { accent: need(v, '--vk-color-accent', sel), fg: need(v, '--vk-color-accent-fg', sel), wash: need(v, '--vk-color-accent-wash', sel), text: need(v, '--vk-color-accent-text', sel) };
}

/** What each status word means, in the order a product grows through them. */
export const STATUSES = {
  'wet-paint': { label: 'wet paint', means: 'New or experimental.', mood: 'needs' },
  'half-lit': { label: 'half-lit', means: 'Works, with known gaps the page names.', mood: 'done' },
  'lights-on': { label: 'lights on', means: 'In production, still changing.', mood: 'thinking' },
  'lit-and-steady': { label: 'lit & steady', means: 'In production, stable, relied on daily.', mood: 'working' },
};
export const STATUS_KEYS = Object.keys(STATUSES);

/** Accepts the key or the word a writer would type ("lit & steady", "wet paint"). */
export function statusOf(value) {
  if (typeof value !== 'string') return undefined;
  const v = value.trim().toLowerCase();
  return STATUS_KEYS.find((k) => k === v || STATUSES[k].label === v || k.replace(/-/g, ' ') === v);
}

/** The status fills (vibekit's mood colours) and the ink that reads on them (its face ink). */
export function statusColours(tokensCss, theme) {
  const sel = `[data-vibe="${VIBE}"][data-theme="${theme}"]`;
  const v = block(tokensCss, sel);
  const out = Object.fromEntries(STATUS_KEYS.map((k) => [k, need(v, `--vk-mood-${STATUSES[k].mood}`, sel)]));
  // Face ink: the Daylight light text colour, which vibekit keeps at 4.5:1 on every mood in both themes.
  const ink = need(block(tokensCss, `[data-vibe="${VIBE}"][data-theme="light"]`), '--vk-color-text', 'daylight light');
  return { ...out, ink };
}

/** The neutral grey scale every docs site shares, from page text (white) to the page itself (black), Starlight's way. */
export const GREYS = {
  dark: {
    white: '#f2f0f7', 'gray-1': '#e4e2ea', 'gray-2': '#c9c6d2', 'gray-3': '#a3a0ad', 'gray-4': '#62606c',
    'gray-5': '#2c2b34', 'gray-6': '#1a1a20', 'gray-7': '#131317', black: '#0d0d11',
  },
  light: {
    white: '#16151a', 'gray-1': '#26252b', 'gray-2': '#3b3a41', 'gray-3': '#5e5b66', 'gray-4': '#8d8a94',
    'gray-5': '#dedad3', 'gray-6': '#efece6', 'gray-7': '#ffffff', black: '#f7f6f3',
  },
};

// ---- colour arithmetic (sRGB, WCAG 2) --------------------------------------------------------

const channels = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
const lin = (c) => { const s = c / 255; return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4; };
export const luminance = (hex) => { const [r, g, b] = channels(hex).map(lin); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
export const contrast = (a, b) => { const [x, y] = [luminance(a), luminance(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
/** `a` mixed toward `b` by `t` (0..1), per sRGB channel. */
export const mix = (a, b, t) => {
  const [p, q] = [channels(a), channels(b)];
  return `#${p.map((c, i) => Math.round(c + (q[i] - c) * t).toString(16).padStart(2, '0')).join('')}`;
};

/** Every colour the theme sets, per theme. */

export function paletteOf(accentsCss, tokensCss, accent, theme) {
  const a = accentOf(accentsCss, accent, theme);
  const greys = GREYS[theme];
  const status = statusColours(tokensCss, theme);
  if (theme === 'dark') {
    // Links read accent-high on the dark page; a filled accent (the current sidebar item, the
    // primary button) carries the page's own black.
    return { greys, accentLow: a.wash, accent: a.accent, accentHigh: a.text, textInvert: greys.black, brand: a.accent, brandInk: greys.black, status };
  }
  // In light, Starlight writes links in --sl-color-accent, so that is vibekit's accent-text (4.5:1
  // on the page); accent-high, for text on the pale wash, is the same hue taken a third darker.
  return { greys, accentLow: a.wash, accent: a.text, accentHigh: mix(a.text, '#000000', 0.33), textInvert: '#ffffff', brand: a.accent, brandInk: '#ffffff', status };
}

const decls = (p) => [
  ...Object.entries(p.greys).map(([k, v]) => `--sl-color-${k}: ${v};`),
  `--sl-color-accent-low: ${p.accentLow};`, `--sl-color-accent: ${p.accent};`, `--sl-color-accent-high: ${p.accentHigh};`,
  `--sl-color-text-invert: ${p.textInvert};`,
  `--sjl-brand: ${p.brand};`, `--sjl-brand-ink: ${p.brandInk};`,
  ...STATUS_KEYS.map((k) => `--sjl-status-${k}: ${p.status[k]};`), `--sjl-status-ink: ${p.status.ink};`,
].join(' ');

/**
 * The colour tokens for one product, as CSS: dark on html:root (Starlight's default) and light under
 * [data-theme='light']. `html:root` outranks Starlight's own :root defaults whatever the bundle order.
 */
export function themeCss(accentsCss, tokensCss, accent) {
  return `html:root { ${decls(paletteOf(accentsCss, tokensCss, accent, 'dark'))} }\nhtml:root[data-theme='light'] { ${decls(paletteOf(accentsCss, tokensCss, accent, 'light'))} }`;
}

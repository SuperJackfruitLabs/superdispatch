# Changelog

## 0.0.2

- **A quieter foot.** Only the docs home and the 404 wear frontdoor's full suite footer. Every other page keeps Starlight's previous and next, edit link and last-updated date, then one line: "Part of Super Jackfruit Labs" and a Products switcher that opens the suite's list.
- **FlowSteps is a tablist.** The range slider is gone. The steps are numbered tabs with one tab stop; Left and Right follow the text direction, Home and End jump, and the arrows stop at either end (`loop` wraps). Back and Next are 44px targets that keep focus at either end. Transitions run only under `prefers-reduced-motion: no-preference`; the stepper works the same with reduced motion. The pattern follows Vercel's UI SDK tabs, focus and motion docs, and lives in `src/client/steps.ts`.
- **`DecisionReplay`**, a new component: a recorded SuperDispatch placement decision, stepped through with the same tabs, from a JSON file in the site. Nothing to install.
- **`CopyPrompt`**, a new component: a prompt for a coding agent naming the product's `llms.txt` and `llms-full.txt`. BentoHome shows it in a new Work with an agent tile (`agent`, or `agent={false}`).
- **Every page as Markdown** at `<page>.md`, and an Open as Markdown link beside Copy Markdown. Both give the same text.
- **BentoHome**: the Quick start takes a `quickstart` slot, for a quick start that needs nothing installed, and spans the full width. The Quick start's Copy and Copy Markdown announce "Copied". When the clipboard is blocked, the Quick start's Copy selects the command.
- **Controls.** Captain Jack's Ask button stays focusable while he reads. A theme button with the `hidden` attribute is now hidden; before, its `display` overrode it. On touch screens theme buttons are at least 44px tall.
- **Tests.** `npm run e2e` drives the fixture in Chrome. The fixture build points `cookie` at Astro's own copy, so it builds in the workspace again.

## 0.0.1

The first release, with frontdoor 0.0.15. See frontdoor's CHANGELOG.

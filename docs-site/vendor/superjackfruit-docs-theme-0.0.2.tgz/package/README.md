# @superjackfruit/docs-theme

The suite's docs design, as one Starlight plugin. A product's docs site sets its title, its sidebar and this:

```js
// astro.config.mjs
import starlight from '@astrojs/starlight';
import sjlDocs from '@superjackfruit/docs-theme';

starlight({
  title: 'SuperDispatch',
  plugins: [sjlDocs({ product: 'superdispatch', status: 'wet paint' })],
  sidebar: [/* Start, Use it, Build on it, Run it, Reference */],
});
```

```ts
// src/content.config.ts: Starlight's schema plus `status:`
import { defineCollection } from 'astro:content';
import { docsLoader } from '@astrojs/starlight/loaders';
import { sjlDocsSchema } from '@superjackfruit/docs-theme/schema';

export const collections = { docs: defineCollection({ loader: docsLoader(), schema: sjlDocsSchema() }) };
```

## What the plugin brings

- **Colours from vibekit.** It reads the product's accent from vibekit's `PRODUCT_ACCENTS` and its Daylight values from `accents.css`, for light and dark. Every site shares one neutral grey scale, so the products differ only in their accent. No product colour is typed in this package.
- **Faces, self-hosted.** Bricolage Grotesque for display, IBM Plex Sans for body text and IBM Plex Mono for code. The font files are bundled into the site, so no page fetches a font from Google.
- **The header.** The site title shows the product's mark and name, plus the site's status when the `status` option is set. Above it, the street is the suite map: one house per product, leading to that product's docs. On a phone the street folds into a product switcher. The header also links to the product's landing page.
- **Page titles.** Each page gets a status badge from its frontmatter `status:`, a Copy Markdown button and an Open as Markdown link.
- **Every page as Markdown.** Each page is also served at its own address plus `.md` (`/start/first-steps.md`, `/index.md` for the home): the title and the body as written, MDX imports dropped. It is the same text Copy Markdown copies. `starlight-llms-txt` serves only the whole-site files, so the theme adds this route itself.
- **The foot of the page.** Starlight's own edit link, last-updated date and previous/next links come first. The docs home and the 404 then wear frontdoor's full suite footer. Every other page ends with one quiet line instead: "Part of Super Jackfruit Labs" and a Products switcher that opens the suite's list.
- **A 404 with character**: "You've wandered off the street", with search, a link to the docs home and a link to the landing page.
- **Defaults**: `starlight-llms-txt` is on (`llms: false` turns it off), `editLink` points at the product's repo (`docsDir` sets the folder, `docs-site/` by default), and `lastUpdated: true`. A site's own settings win.
- **A sidebar check.** The build warns when the top-level groups are not Start / Use it / Build on it / Run it / Reference, in that order. A site may leave groups out.

## Status words

| Word | Means |
|---|---|
| lit & steady | In production, stable, relied on daily. |
| lights on | In production, still changing. |
| half-lit | Works, with known gaps the page names. |
| wet paint | New or experimental. |

Each badge is filled with vibekit's mood colours, never the accent.

## Components for pages

Import these in `.mdx` from `@superjackfruit/docs-theme/components/<Name>.astro`.

- `BentoHome`: the docs home, for `index.mdx` with `template: splash` and no `hero`. It takes `claim`, `sub`, `actions`, `quickstart` (`{ command, label?, note? }`), `status`, `ask` (`{ examples }`, or `false`), `agent` (`{ task?, prompt? }`, or `false`), `flowTitle` and `map`. Whatever you put inside it fills the "how it works" tile. An element with `slot="quickstart"` replaces the Quick start's command, for a quick start that needs nothing installed, such as a `DecisionReplay`; `quickstart` then takes only `label` and `note`.
- `FlowSteps`: a process the reader steps through: numbered steps as a tablist, a lane per step that fills in as the steps are reached, the selected step's panel, and Back and Next. It never moves by itself.
- `DecisionReplay`: a recorded placement decision, replayed in the same steps: the card ready, every candidate with each filter's result and reason code, the scores, the hold and the claim. Pass `decision`, a JSON file in the site holding a decision as SuperDispatch's operator API returns it, and `source`, a line saying where it was recorded.
- `CopyPrompt`: a prompt to paste into a coding agent. It tells the agent to read the product's `llms.txt` and `llms-full.txt`, then do `task`. BentoHome shows it in its Work with an agent tile.
- `Switcher`: the product switcher (the street on a phone, and the foot of a content page).
- `CaptainJack`: the Ask box. It sends the question to the suite worker at this site's own `/captain/`. Captain Jack answers only from the product's docs and the lab's checked claims, and links each docs passage he cites. When the docs don't cover a question, he says "I don't know".
- `Tip`, `HeadsUp`, `WetPaint`, `JackAside`: the callouts.
- `StatusBadge`: a status word as a pill.

## Steps, keys and focus

`FlowSteps` and `DecisionReplay` share one pattern (`src/client/steps.ts`), after the tabs, focus and motion pages of Vercel's UI SDK docs:

- The steps are a `tablist` with one tab stop: the selected step's tab has `tabindex="0"`, the rest `-1`.
- Left and Right move to the next or previous step in the page's text direction, Home and End to the first and last. The arrows stop at either end (`FlowSteps` takes `loop` to wrap). Moving selects the step.
- Each tab has `aria-selected` and `aria-controls`; its panel has `role="tabpanel"` and `aria-labelledby`. Only the selected panel is shown.
- Back and Next are at least 44px square. At either end they are `aria-disabled`, not `disabled`, so focus stays on the button.
- Nothing moves by itself. Transitions run only under `prefers-reduced-motion: no-preference`.
- Every tab, panel and button has a visible focus ring. Tabs are at least 44px.
- Without JavaScript, every step's panel is written out and the tablist stays hidden.

Copy buttons (Copy Markdown, Copy prompt, the Quick start's Copy) say "Copied" and announce it in a live region. Focus stays on the button. On touch screens every theme button is at least 44px tall.

## Peers

`astro` 7, `@astrojs/starlight` 0.42, `starlight-llms-txt` 0.12, `@superjackfruit/vibekit` 0.0.16 or later, and `@superjackfruit/frontdoor` 0.0.15 or later (product list, marks and suite footer). Both `@superjackfruit` packages are vendored as tarballs, the way the landing pages vendor them.

## Tests

`npm test` builds `fixture/`, a small Starlight site that wears the theme. It then checks that build, the plugin's config, the tokens against vibekit's own CSS, and contrast for every product in light and dark.

`npm run e2e` builds the fixture and drives it in an installed Chrome (Playwright, `channel: 'chrome'`): the step keys and focus, right-to-left, reduced motion, no JavaScript, the copy buttons, the `.md` pages and the foot of the page.

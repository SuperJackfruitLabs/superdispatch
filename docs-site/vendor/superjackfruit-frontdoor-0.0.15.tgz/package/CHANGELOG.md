# Changelog

Earlier releases are described in their release commits and forge release notes.

## 0.0.15

- **Product colours come from vibekit** (0.0.16, vendored). AgentPod is now cobalt (`#508ff7`, was `#2196f3`), SuperLibrary is plum (`#da70c6`, was the coral `#f2704e`) and Salaam is pink (`#f64787`, was `#f74783`). Each new colour keeps the old mark's OKLCH lightness and chroma at vibekit's accent hue, and the `hi` variants follow. `test/colours.test.ts` checks every product's colour and `hi` against vibekit's `PRODUCT_ACCENTS` and `ACCENT_HUES`, within 3°. SuperMessage, SuperPipeline, SuperWitness and SuperToolkit predate vibekit's palette and sit 5° to 10.5° off; their offsets are pinned and may only shrink. A landing page that moves to 0.0.15 changes colour for AgentPod, SuperLibrary and Salaam. The brand marks (the SVGs) are unchanged, so SuperLibrary's mark is still drawn in coral.
- **`@superjackfruit/docs-theme` 0.0.1**, a new package in `packages/docs-theme`. It is a Starlight plugin that gives a product's docs site the suite's design: vibekit's colours for the product, Bricolage Grotesque, IBM Plex Sans and IBM Plex Mono (self-hosted), the street as the suite map, status badges, Copy Markdown, the suite footer, a 404 with character, llms.txt, edit links, last-updated dates and a sidebar check. It also has page components: `BentoHome`, `FlowSteps`, `CaptainJack` and the callouts. See its README.
- **Captain Jack on the docs sites.** The suite worker is now also routed at `/captain/*` on every docs domain (`docs.<domain>`, and `treaty.superjackfruit.com` for Treaty), so a docs page asks him same-origin, as a landing page does. Treaty joins `DOCS`, so he reads Treaty's `/llms-full.txt` and names it exactly. The routes take effect only when the worker is redeployed.

## 0.0.14

- SuperDispatch and SuperExchange link their docs sites, https://docs.superdispatch.dev and https://docs.superexchange.dev, labelled "Docs" like the other products, in place of the GitHub README. Their llms.txt is now the docs site's (`/llms.txt`), not the landing page's.
- Captain Jack links both docs sites in his answers, and the suite worker reads their `/llms-full.txt` as a docs source. The worker change takes effect only when the worker is redeployed.

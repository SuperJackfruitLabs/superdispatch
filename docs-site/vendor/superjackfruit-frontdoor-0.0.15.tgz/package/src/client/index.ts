import { mountThemeButton } from './theme';
import { early, mountDoorway, prefetchOnIntent } from './doorway';
import { mountHeader } from './header';
import { mountClaims } from './claims';
import { mountFooter } from './footer';
import { mountBackdrop } from './backdrop';
import { mountMicro } from './micro';
import { mountJack } from './jack';
import { SITES, type Site } from '../data/products';

export * from './theme';
export { mountJack, JACK_URL } from './jack';
export { leaveTo, revealArrival, prefetchOnIntent } from './doorway';

export interface FrameOpts {
  product?: Site;
  /** Captain Jack's endpoint (Task 7). */
  jackUrl?: string;
  /** Called for every "ask Captain Jack" in the frame. Defaults to a `sjl-ask` event on window,
   *  which the frame's own Captain Jack sheet answers; a site that passes onAsk brings its own. */
  onAsk?: (question?: string) => void;
}

const ask = (question?: string): void => { dispatchEvent(new CustomEvent('sjl-ask', { detail: { question } })); };

/** Wires every client behaviour of the frame. Called once from Frame.astro's script. Each part is independent. */
export function mountFrame(opts: FrameOpts = {}): void {
  const host = (tag: string) => document.querySelector(tag)?.shadowRoot ?? null;
  const product = (opts.product ?? document.querySelector<HTMLElement>('sjl-product-header,sjl-footer')?.dataset.product) as Site | undefined;
  const onAsk = opts.onAsk ?? ask;
  const safe = (f: () => void) => { try { f(); } catch (e) { console.warn('[sjl-frame]', e); } };

  safe(() => { const bar = host('sjl-suite-bar'); if (bar) mountThemeButton(bar); });
  safe(mountDoorway);
  if (!product || !SITES[product]) return;
  const header = host('sjl-product-header');
  if (header) safe(() => mountHeader(header, { product, onAsk }));
  if (!opts.onAsk) safe(() => { mountJack({ product, jackUrl: opts.jackUrl, headRoot: header }); });
  const claims = host('sjl-claims');
  if (claims) safe(() => mountClaims(claims, { onAsk }));
  const footer = host('sjl-footer');
  if (footer) safe(() => mountFooter(footer, { product, from: early()?.from ?? null, onAsk }));
  safe(() => { const bar = host('sjl-suite-bar'); if (bar) prefetchOnIntent(bar); });
  safe(() => {
    const root = host('sjl-suite-bar'), dlg = root?.getElementById('fa') as HTMLDialogElement | null;
    if (!root || !dlg) return;
    root.querySelector('.agents')?.addEventListener('click', () => dlg.showModal());
    root.getElementById('fa-x')?.addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  });
  safe(() => { if (footer) prefetchOnIntent(footer); });
  safe(() => mountBackdrop(product));
  safe(() => mountMicro({ product, header }));
}

// The product header's behaviour (ported from the prototype's frame.js): sticky and compact
// past scrollY 24, the ☰ drawer (a <details>, so it opens without JS), "/" to the Ask field,
// and the version pill refreshed from the suite worker's /captain/releases.
import type { Site } from '../data/products';
import { liveRelease, releasedOn } from './release';

export interface HeaderOpts { product: Site; onAsk?: (question?: string) => void }

const typing = (el: Element | null): boolean => {
  let e: Element | null = el;
  while (e?.shadowRoot?.activeElement) e = e.shadowRoot.activeElement;
  return !!e && (/^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName) || (e as HTMLElement).isContentEditable);
};

export function mountHeader(root: ShadowRoot, opts: HeaderOpts): void {
  const h = root.getElementById('h');
  if (h) {
    const stick = () => h.classList.toggle('stuck', scrollY > 24);
    addEventListener('scroll', stick, { passive: true });
    stick();
  }

  const menu = root.getElementById('menu') as HTMLDetailsElement | null;
  const summary = menu?.querySelector('summary');
  if (menu && summary) {
    const sync = () => summary.setAttribute('aria-expanded', String(menu.open));
    menu.addEventListener('toggle', sync);
    sync();
    root.getElementById('drawer')?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => (menu.open = false)));
  }

  const ask = root.getElementById('askj') as HTMLButtonElement | null;
  if (ask) {
    ask.addEventListener('click', () => opts.onAsk?.());
    addEventListener('keydown', (e) => {
      if (e.key !== '/' || e.metaKey || e.ctrlKey || e.altKey || typing(document.activeElement)) return;
      e.preventDefault();
      ask.focus();
    });
  }

  void refreshVersion(root, opts.product);
}

/** The build bakes in a release; a newer one shows up without a rebuild. Silent on any failure. */
async function refreshVersion(root: ShadowRoot, slug: Site): Promise<void> {
  const v = root.getElementById('ver') as HTMLAnchorElement | null;
  if (!v) return;
  const r = await liveRelease(slug);
  if (!r) return;
  v.textContent = r.tag;
  v.href = r.url;
  const on = releasedOn(r);
  if (on) v.title = on;
}

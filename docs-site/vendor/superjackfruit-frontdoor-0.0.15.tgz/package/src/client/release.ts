// The latest release, fetched once per page from the suite worker on this site's own origin
// (/captain/releases/<product>, see worker/src/releases.ts), never from api.github.com: the
// worker holds the GitHub token and the cache. The build bakes in a release; this only brings a
// newer one without a rebuild. Silent on any failure: the built value stays.
import { SITES, type Site, type Slug } from '../data/products';

export interface LiveRelease { tag: string; url: string; published_at: string | null }

let pending: Promise<LiveRelease | null> | null = null;

export function liveRelease(slug: Site): Promise<LiveRelease | null> {
  if (slug === 'lab' || !SITES[slug]?.repo) return Promise.resolve(null);
  return (pending ??= (async () => {
    try {
      const r = await fetch(`/captain/releases/${slug as Slug}`, { headers: { accept: 'application/json' } });
      if (!r.ok) return null;
      const b = await r.json();
      if (typeof b?.tag !== 'string' || !/^v?\d/.test(b.tag) || typeof b?.url !== 'string' || !b.url.startsWith('https://')) return null;
      return { tag: b.tag, url: b.url, published_at: typeof b.published_at === 'string' ? b.published_at : null };
    } catch {
      return null;
    }
  })());
}

/** "Released Tue Oct 22 2026", for a title attribute. */
export const releasedOn = (r: LiveRelease): string | null => {
  if (!r.published_at) return null;
  const d = new Date(r.published_at);
  return Number.isNaN(d.getTime()) ? null : `Released ${d.toDateString()}`;
};

// Browser side of the suite theme: the preference, the fragment carrying it to the next
// product, and the bar's theme button. The logic is theme-core.js, which SuiteHead.astro also
// inlines into the head script, so first paint and later changes can never disagree.
import { mountThemeSwitch, type ThemePreference } from '@superjackfruit/vibekit/dom';
import { SITES, type Site } from '../data/products';
import { createTheme, matchFragment, parsePref, PREF_KEY, type Pref, type Theme } from './theme-core.js';

export type { Pref };

/** Switcher order on landing pages: no 'sun'. */
export const ORDER: Pref[] = ['light', 'system', 'dark'];

// Prototype frame.js ICON.
export const ICON: Record<Pref, string> = {
  light: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
  system: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>',
  dark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>',
};

const HOSTS = 'sjl-suite-bar,sjl-product-header,sjl-claims,sjl-footer';

const read = (k: string): string | null => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k: string, v: string | null): void => {
  try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch { /* private mode: still theme the page */ }
};

function themeFor(slug: Site): Theme {
  const p = SITES[slug];
  return createTheme({
    site: { key: p.themeKey, values: { light: p.themeValue('light'), dark: p.themeValue('dark') } },
    read,
    write,
    systemLight: () => matchMedia('(prefers-color-scheme: light)').matches,
    paint(siteValue, effective) {
      const html = document.documentElement;
      html.dataset.theme = siteValue;
      html.dataset.sjlTheme = effective;
      document.querySelectorAll(HOSTS).forEach((h) => h.setAttribute('data-sjl-theme', effective));
    },
  });
}

export function readPref(): Pref {
  return parsePref(read(PREF_KEY));
}

/** Writes the suite preference and the site's own key, then themes the page and every frame host. */
export function setPref(slug: Site, pref: Pref): void {
  const early = (globalThis as { __sjlFrameEarly?: { theme: { set(p: Pref): void } } }).__sjlFrameEarly;
  // The head script owns the live matchMedia listener: go through it when it is there.
  if (early) early.theme.set(pref); else themeFor(slug).set(pref);
}

export function carryFragment(): string {
  return `#sjl-theme=${readPref()}`;
}

/** If the URL is exactly '#sjl-theme=…', returns it and removes it from the address bar. Any other fragment is left alone. */
export function consumeFragment(loc: Location): Pref | null {
  const carried = matchFragment(loc.hash);
  if (carried) history.replaceState(null, '', loc.pathname + loc.search);
  return carried;
}

/** Turns the bar's #mode button into the one-icon theme switch. */
export function mountThemeButton(barRoot: ShadowRoot): { destroy(): void } | null {
  const button = barRoot.querySelector<HTMLButtonElement>('#mode');
  const slug = (barRoot.host.getAttribute('data-product') ?? '') as Site;
  if (!button || !SITES[slug]) return null;
  return mountThemeSwitch(button, {
    order: ORDER as ThemePreference[],
    icons: ICON,
    current: readPref(),
    onChange: (t) => setPref(slug, t as Pref),
  });
}

// Claims are <details>, so they open without JS. The client adds aria-expanded, slides the
// caveat open (not under reduced motion), and hands "Ask Captain Jack about this" to onAsk.
const still = (): boolean => matchMedia('(prefers-reduced-motion: reduce)').matches;

export function mountClaims(root: ShadowRoot, opts: { onAsk: (question: string) => void }): void {
  root.querySelectorAll<HTMLDetailsElement>('details.claim').forEach((d) => {
    const head = d.querySelector('summary');
    const more = d.querySelector<HTMLElement>('.more');
    const sync = () => head?.setAttribute('aria-expanded', String(d.open));
    sync();
    d.addEventListener('toggle', () => {
      sync();
      if (d.open && more && !still()) {
        more.animate([{ opacity: 0, transform: 'translateY(-4px)' }, { opacity: 1, transform: 'none' }], { duration: 300, easing: 'cubic-bezier(.2,.8,.2,1)' });
      }
    });
  });
  root.querySelectorAll<HTMLButtonElement>('.askit').forEach((b) => b.addEventListener('click', () => opts.onAsk(b.dataset.q ?? '')));
}

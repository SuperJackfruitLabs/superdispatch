// Ported from the prototype's public/backdrop.js; the lab motif was added since.
export function mountBackdrop(opts: { product: string; color: string; theme: () => 'light' | 'dark'; palette?: string[] }): { setTheme(t: 'light' | 'dark'): void };

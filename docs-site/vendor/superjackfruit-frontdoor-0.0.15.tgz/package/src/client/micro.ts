// Small motions shared by every product page (ported from the prototype's micro.js). The page-level
// ones are vibekit's primitives (@superjackfruit/vibekit/dom); only the header logo's brand
// motion stays here. Every one is skipped
// under prefers-reduced-motion, and nothing is hidden before this script adds a class.
import { copyFeedback, magnetic, revealOnScroll, tilt, underlineDraw } from '@superjackfruit/vibekit/dom';
import vkDom from '@superjackfruit/vibekit/dom.css?raw';
import { STATIC_MARK, type Site } from '../data/products';

const STYLE_ID = 'sjl-vk-dom';

/** vibekit's dom.css on the page itself (reveal, underline, tilt and copy act on the page body), once. */
function injectDomCss(): void {
  if (document.getElementById(STYLE_ID)) return;
  const s = document.createElement('style');
  s.id = STYLE_ID;
  s.textContent = vkDom;
  document.head.append(s);
}

type Motion = { create(container: Element, slug: string): { play(): Promise<unknown> | void } };

async function logoOnHover(root: ShadowRoot, product: Site): Promise<void> {
  if (STATIC_MARK.has(product)) return;
  const mark = root.getElementById('mark');
  const brand = root.getElementById('brand');
  if (!mark || !brand) return;
  try {
    await import('../vendor/logo-motion.js');
    const M = (globalThis as { SJLLogoMotion?: Motion }).SJLLogoMotion;
    if (!M) return;
    const box = document.createElement('div');
    box.style.cssText = 'width:100%;height:100%';
    const logo = M.create(box, product);
    mark.replaceChildren(box);
    let busy = false;
    brand.addEventListener('pointerenter', () => {
      if (busy) return;
      busy = true;
      Promise.resolve(logo.play()).finally(() => (busy = false));
    });
  } catch { /* the static mark stays */ }
}

/** The lab's Facet mark: a small turn and lift, as if catching the light. */
function facetOnHover(root: ShadowRoot): void {
  const s = document.createElement('style');
  s.textContent = `#mark svg{transition:transform .45s cubic-bezier(.3,1.6,.5,1),filter .45s}
#brand:hover #mark svg,#brand:focus-visible #mark svg{transform:rotate(-10deg) scale(1.1);filter:drop-shadow(0 2px 6px color-mix(in srgb,var(--sjl-c) 55%,transparent))}`;
  root.append(s);
}

export function mountMicro(opts: { product: Site; header?: ShadowRoot | null }): void {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  injectDomCss();
  const { header } = opts;
  if (header) {
    if (opts.product === 'lab') facetOnHover(header); // the brand motion has no lab mark
    else void logoOnHover(header, opts.product);
    const s = document.createElement('style');
    s.textContent = vkDom.split('\n').filter((l) => l.startsWith('.vk-mag')).join('\n');
    header.append(s);
  }

  // list items reveal one by one (a grid of cards staggers in, not as one block)
  const hero = document.querySelector('h1')?.closest('section') ?? null;
  const targets = [...document.querySelectorAll('section h2, section h3, section p, section pre, section ul > li, section ol > li')]
    .filter((el) => !hero?.contains(el) && !el.closest('header, footer, nav, figure'));
  revealOnScroll(targets.filter((el) => !targets.some((t) => t !== el && t.contains(el))));

  const ctas = [...document.querySelectorAll<HTMLElement>('a, button')]
    .filter((el) => /^\s*get started\b/i.test(el.textContent ?? '') && (el.textContent ?? '').trim().length < 24 && !el.closest('header, footer'));
  const headCta = header?.querySelector<HTMLElement>('.cta');
  for (const el of headCta ? [...ctas, headCta] : ctas) magnetic(el);

  document.querySelectorAll<HTMLButtonElement>('button').forEach((b) => {
    if (/copy/i.test(`${b.textContent} ${b.getAttribute('aria-label') ?? ''} ${b.id}`)) copyFeedback(b);
  });

  underlineDraw(document);

  if (hero) {
    const text = document.querySelector('h1');
    const grid = [hero, ...hero.querySelectorAll('*')].find((el) => el.children.length >= 2 && [...el.children].some((c) => c.contains(text)) && getComputedStyle(el).display === 'grid');
    const demo = grid && [...grid.children].find((c) => !c.contains(text));
    if (demo instanceof HTMLElement) tilt(demo);
  }
}

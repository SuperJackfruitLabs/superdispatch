// Helpers shared by the frame's server-rendered components. Each component builds its shadow
// root's inner HTML as a string and emits it inside <template shadowrootmode="open">.
import tokens from './styles/tokens.css?raw';
import jackSvg from '../brand/captain-jack.svg?raw';
import supermessage from '../brand/supermessage.svg?raw';
import superpipeline from '../brand/superpipeline.svg?raw';
import superlibrary from '../brand/superlibrary.svg?raw';
import superwitness from '../brand/superwitness.svg?raw';
import agentpod from '../brand/agentpod.svg?raw';
import salaam from '../brand/salaam.svg?raw';
import superdispatch from '../brand/superdispatch.svg?raw';
import superexchange from '../brand/superexchange.svg?raw';
import supertoolkit from '../brand/supertoolkit.svg?raw';
import lab from '../brand/lab.svg?raw';
import { onColor, SITES, type Product, type Site } from '../data/products';

export const LOGOS: Record<Site, string> = { supermessage, superpipeline, superlibrary, superwitness, agentpod, salaam, superdispatch, superexchange, supertoolkit, lab };

export const esc = (s: string): string =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

export const product = (slug: Site): Product => {
  const p = SITES[slug];
  if (!p) throw new Error(`frontdoor: unknown product "${slug}"`);
  return p;
};

/** Decorative copy of an SVG: no title/desc, hidden from assistive tech, sized by class. */
const decorative = (svg: string, cls: string): string =>
  svg.replace(/<\?xml[^>]*>/, '').replace(/<title[^>]*>[\s\S]*?<\/title>/, '').replace(/<desc[^>]*>[\s\S]*?<\/desc>/, '')
    .replace(/<svg\b([^>]*)>/, (_, a: string) => `<svg${a.replace(/\s(role|aria-label|aria-labelledby|width|height)="[^"]*"/g, '')} class="${cls}" aria-hidden="true" focusable="false">`)
    .trim();

/** Captain Jack, the delivered rig, drawn static. */
export const jack = (): string => decorative(jackSvg, 'jack');
export const logo = (slug: Site): string => decorative(LOGOS[slug], 'logo');

/** The opening of a shadow root: shared tokens, the product colours, the component's CSS. */
export const styles = (p: Product, css: string): string => {
  return `<style>${tokens}:host{--sjl-c:${p.color};--sjl-c-hi:${p.hi};--sjl-on-c:${onColor(p)}}${css}</style>`;
};

export const SUITE_URL = 'https://superjackfruit.com';

/** The GitHub mark, sized by its container; the header and the footer both use it. */
export const GH = '<svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>';
